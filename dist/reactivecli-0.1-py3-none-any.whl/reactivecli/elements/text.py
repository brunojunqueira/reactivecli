from reactivecli.bases import Element


class Text(Element):

    def __init__(self, state, style={}):
        super().__init__(state, style)
